function SpawnRegions()
	return {
		{ name = "Muldraugh, KY", file = "media/maps/Muldraugh, KY/spawnpoints.lua" },
		{ name = "Riverside, KY", file = "media/maps/Riverside, KY/spawnpoints.lua" },
		{ name = "Rosewood, KY", file = "media/maps/Rosewood, KY/spawnpoints.lua" },
		{ name = "West Point, KY", file = "media/maps/West Point, KY/spawnpoints.lua" },
		{ name = "Grapeseed", file = "media/maps/Grapeseed/spawnpoints.lua" },
		{ name = "InsurgentSpawn", file = "media/maps/InsurgentSpawn/spawnpoints.lua" },
		{ name = "Louisville, KY", file = "media/maps/Louisville, KY/spawnpoints.lua" },
		{ name = "ModTemplateWorld1", file = "media/maps/ModTemplateWorld1/spawnpoints.lua" },
		{ name = "ModTemplateWorld2", file = "media/maps/ModTemplateWorld2/spawnpoints.lua" },
		{ name = "Rosewood VHS Store", file = "media/maps/Rosewood VHS Store/spawnpoints.lua" },
	}
end
